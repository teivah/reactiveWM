package reactiveWM.v1;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-05-19 22:06:27 CEST
// -----( ON-HOST: QASSNEIP01.ppmail.ppservices.axa-tech.intraxa

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.reactivewm.facade.ReactiveWMFacade;
import com.wm.data.IData;
// --- <<IS-END-IMPORTS>> ---

public final class priv

{
	// ---( internal utility methods )---

	final static priv _instance = new priv();

	static priv _newInstance() { return new priv(); }

	static priv _cast(Object o) { return (priv)o; }

	// ---( server methods )---




	public static final void logMessage (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(logMessage)>> ---
		// @sigtype java 3.5
		// [i] field:0:optional loggerName
		// [i] field:0:required logSeverity {"DEBUG","INFO","WARN","ERROR","FATAL"}
		// [i] field:0:optional logMessage
		IDataCursor pipelineCur = pipeline.getCursor();
		
		try {
			String loggerName = IDataUtil.getString(pipelineCur, "loggerName");
			String logSeverity = IDataUtil.getString(pipelineCur, "logSeverity");
			String logMessage = IDataUtil.getString(pipelineCur, "logMessage");
			Logger logger = org.apache.log4j.Logger.getLogger(loggerName);
			logger.log(Level.toLevel(logSeverity), logMessage);
		} catch(Exception e) {
			
		}
		
		pipelineCur.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void shutdown (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(shutdown)>> ---
		// @sigtype java 3.5
		ReactiveWMFacade.shutdown();
		// --- <<IS-END>> ---

                
	}



	public static final void startup (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(startup)>> ---
		// @sigtype java 3.5
		// [o] record:1:required pools
		// [o] - field:0:required pool
		// [o] - field:0:required size
		IDataCursor pipelineCur = pipeline.getCursor();
		Properties properties = System.getProperties();
		
		Enumeration<?> e = properties.propertyNames();
		Map<String, String> map = new HashMap<String, String>();
		while (e.hasMoreElements()) {
			String key = (String)e.nextElement();
			if(key != null && key.startsWith(POOL_PROPERTY)) {
				String pool = key.substring(POOL_PROPERTY.length(), key.length());
				map.put(pool, properties.getProperty(key));
			}
		}
		
		if(map.size() != 0) {
			IData[] pools = new IData[map.size()];
			int i=0;
			IDataCursor poolCur = null;
			
			for(Map.Entry<String, String> entry : map.entrySet()) {
				IData pool = IDataFactory.create();
				poolCur = pool.getCursor();
				IDataUtil.put(poolCur, "pool", entry.getKey());
				IDataUtil.put(poolCur, "size", entry.getValue());
				pools[i++] = pool;
			}
			
			if(poolCur != null) {
				poolCur.destroy();
			}
			
			IDataUtil.put(pipelineCur, "pools",	pools);
		}
		
		ReactiveWMFacade.startup(10000);
		pipelineCur.destroy();
					
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	private static final String POOL_PROPERTY = "watt.aif.pool.";
		
	// --- <<IS-END-SHARED>> ---
}

