package reactiveWM.v1;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-05-19 22:06:25 CEST
// -----( ON-HOST: QASSNEIP01.ppmail.ppservices.axa-tech.intraxa

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ThreadManager;
import org.reactivewm.facade.ReactiveWMFacade;
// --- <<IS-END-IMPORTS>> ---

public final class admin

{
	// ---( internal utility methods )---

	final static admin _instance = new admin();

	static admin _newInstance() { return new admin(); }

	static admin _cast(Object o) { return (admin)o; }

	// ---( server methods )---




	public static final void introspect (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(introspect)>> ---
		// @specification reactiveWM.v1.spec.admin:introspect
		// @sigtype java 3.5
		IDataCursor pipelineCur = pipeline.getCursor();
		
		try {
			String pool = ReactiveWMFacade.introspect();
			IDataUtil.put(pipelineCur, "pool", pool);
		} finally {
			if(pipelineCur != null) {
				pipelineCur.destroy();
			}
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static final int MAX_THREADS = ThreadManager.getPoolMax();
	// --- <<IS-END-SHARED>> ---
}

