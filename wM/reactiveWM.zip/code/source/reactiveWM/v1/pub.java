package reactiveWM.v1;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-05-19 22:06:29 CEST
// -----( ON-HOST: QASSNEIP01.ppmail.ppservices.axa-tech.intraxa

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.control.ControlException;
import com.wm.app.b2b.server.Session;
import com.wm.app.b2b.server.ThreadManager;
import java.util.ArrayList;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RunnableFuture;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.reactivewm.exception.FailfastException;
import org.reactivewm.exception.ThreadException;
import org.reactivewm.facade.ReactiveWMFacade;
import org.reactivewm.thread.Priority;
import com.google.common.util.concurrent.AsyncFunction;
import com.google.common.util.concurrent.ExecutionList;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.ibm.icu.util.Calendar;
import com.wm.app.b2b.server.ServiceThread;
import com.wm.data.IData;
import com.wm.data.IDataFactory;
import com.wm.data.IDataUtil;
import com.wm.lang.flow.FlowException;
import com.wm.lang.ns.NSName;
// --- <<IS-END-IMPORTS>> ---

public final class pub

{
	// ---( internal utility methods )---

	final static pub _instance = new pub();

	static pub _newInstance() { return new pub(); }

	static pub _cast(Object o) { return (pub)o; }

	// ---( server methods )---




	public static final void chain (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(chain)>> ---
		// @specification reactiveWM.v1.spec.pub:chain
		// @sigtype java 3.5
		IDataCursor pipelineCur = pipeline.getCursor();
		
		try {			
			String pool = IDataUtil.getString(pipelineCur, "pool");
			@SuppressWarnings("unchecked")
			ListenableFuture<IData> future = (ListenableFuture<IData>)IDataUtil.get(pipelineCur, "future");
			
			IData chain = IDataUtil.getIData(pipelineCur, "chain");
			
			if(chain == null) {
				throw new IllegalArgumentException("chain: input service not set");
			}
			
			IDataCursor chainCur = chain.getCursor();
			
			boolean deepClone = getBoolean(chainCur, "deepClone", true);
			String serviceName = IDataUtil.getString(chainCur, "serviceName");
			String sPriority = IDataUtil.getString(chainCur, "priority");
			String priorityRef = IDataUtil.getString(chainCur, "priorityRef");
			boolean merge = getBoolean(chainCur, "merge", true);
			boolean interruptable = getBoolean(chainCur, "interruptable", true);
			IData input = IDataUtil.getIData(chainCur, "input");
			
			chainCur.destroy();
			
			IData failure = IDataUtil.getIData(pipelineCur, "failure");
			
			Future<IData> out = null;
			if(failure == null) {
				try {
					if(deepClone) {
						if(priorityRef != null) {
							out = ReactiveWMFacade.chain(pool, future, serviceName, IDataUtil.deepClone(input), priorityRef, merge, interruptable);
						} else {
							out = ReactiveWMFacade.chain(pool, future, serviceName, IDataUtil.deepClone(input), getPriority(sPriority), merge, interruptable);
						}
					} else {
						if(priorityRef != null) {
							out = ReactiveWMFacade.chain(pool, future, serviceName, input, priorityRef, merge, interruptable);
						} else {
							out = ReactiveWMFacade.chain(pool, future, serviceName, input, getPriority(sPriority), merge, interruptable);
						}	
					}
				} catch (ThreadException e) {
					throw new ServiceException(e);
				}
			} else { 
				IDataCursor failureCur = failure.getCursor();
				
				String errServiceName = IDataUtil.getString(failureCur, "serviceName");
				String errSPriority = IDataUtil.getString(failureCur, "priority");
				String errPriorityRef = IDataUtil.getString(failureCur, "priorityRef");
				boolean errInterruptable = getBoolean(failureCur, "interruptable", true);
				IData errInput = IDataUtil.getIData(failureCur, "input");
				
				failureCur.destroy();
				
				try {
					if(deepClone) {
						if(priorityRef != null) {
							out = ReactiveWMFacade.chain(pool, future, serviceName, IDataUtil.deepClone(input), priorityRef, merge, interruptable, errServiceName, errInput, errPriorityRef, errInterruptable);
						} else {
							out = ReactiveWMFacade.chain(pool, future, serviceName, IDataUtil.deepClone(input), getPriority(sPriority), merge, interruptable, errServiceName, errInput, getPriority(errSPriority), errInterruptable);
						}
					} else {
						if(priorityRef != null) {
							out = ReactiveWMFacade.chain(pool, future, serviceName, input, priorityRef, merge, interruptable, errServiceName, errInput, errPriorityRef, errInterruptable);
						} else {
							out = ReactiveWMFacade.chain(pool, future, serviceName, input, getPriority(sPriority), merge, interruptable, errServiceName, errInput, getPriority(errSPriority), errInterruptable);
						}	
					}
				} catch (ThreadException e) {
					throw new ServiceException(e);
				}
			}
			
			IDataUtil.put(pipelineCur, "chainFuture", out);
			
		} catch(Exception e) {
			throw new ServiceException(e);
		} finally {
			if(pipelineCur != null) {
				pipelineCur.destroy();
			}
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void closePool (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(closePool)>> ---
		// @specification reactiveWM.v1.spec.pub:closePool
		// @sigtype java 3.5
		IDataCursor pipelineCur = pipeline.getCursor();
		String pool = null;
		try {			
			pool = IDataUtil.getString(pipelineCur, "pool");
			
			IData timeout = IDataUtil.getIData(pipelineCur, "timeout");			
			if(timeout == null) {
				throw new IllegalArgumentException("Timeout not set");
			}
			IDataCursor timeoutCur = timeout.getCursor();
			Long duration = parseDurationTimeout(timeoutCur);
			TimeUnit timeUnit = parseTimeUnitTimeout(timeoutCur);
			timeoutCur.destroy();
			
			ReactiveWMFacade.closePool(pool, duration, timeUnit);
			LOG.log(Level.INFO, "Closing thread pool " + pool);
			
		} catch(Exception e) {
			
			boolean silent = getBoolean(pipelineCur, "isSilent", true);
			
			if(silent) {
				LOG.log(Level.DEBUG, "Error while silently closing the thread pool " + pool + ": " + e.getMessage());
			} else {
				LOG.log(Level.ERROR, "Error while closing the thread pool " + pool + ": " + e.getMessage());
				throw new ServiceException(e);
			}
		} finally {
			if(pipelineCur != null) {
				pipelineCur.destroy();
			}
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void createPool (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createPool)>> ---
		// @specification reactiveWM.v1.spec.pub:createPool
		// @sigtype java 3.5
		IDataCursor pipelineCur = pipeline.getCursor();
		
		Properties properties = System.getProperties();
		String sKeepAlive = properties.getProperty(KEEP_ALIVE_PROPERTY, "1");
		long keepAlive = Long.valueOf(sKeepAlive);
		
		String pool = null;
		try {
			pool = IDataUtil.getString(pipelineCur, "pool");
			
			if(pool == null || "".equals(pool)) {
				throw new IllegalArgumentException("Thread pool name not set");
			}
			
			int poolSize = 1;
			
			String sPoolSize = IDataUtil.getString(pipelineCur, "poolSize");
			
			boolean temporary = getBoolean(pipelineCur, "volatile", false);
			boolean atomic = getBoolean(pipelineCur, "atomic", false);
			Date limitDate = null; 
			if(temporary) {
				IData limit = IDataUtil.getIData(pipelineCur, "ttl");			
				if(limit == null) {
					throw new ServiceException("Timeout not set");
				}
				IDataCursor limitCurCur = limit.getCursor();
				Long duration = parseDurationTimeout(limitCurCur);
				TimeUnit timeUnit = parseTimeUnitTimeout(limitCurCur);
				limitCurCur.destroy();
				Calendar cal = Calendar.getInstance();
				cal.setTime(new Date());
				cal.add(Calendar.MILLISECOND, (int)timeUnit.toMillis(duration));
				limitDate = cal.getTime();
			}
			
			if(sPoolSize == null) {
				poolSize = MAX_THREADS;
			} else {
				poolSize = Integer.valueOf(sPoolSize);
				
				if(poolSize <= 0) {
					throw new IllegalArgumentException("Max threads value must be positive");
				} else if(poolSize > MAX_THREADS) {
					poolSize = MAX_THREADS;
				}
			}
			
			ReactiveWMFacade.createPool(pool, poolSize, temporary, limitDate, atomic, keepAlive);
			LOG.log(Level.INFO, "Creating thread pool " + pool + " with a max size set to " + poolSize);
			
		} catch(Exception e) {
			LOG.log(Level.ERROR, "Error while opening the thread pool " + pool + ": " + e.getMessage());
			throw new ServiceException(e);
		} finally {
			if(pipelineCur != null) {
				pipelineCur.destroy();
			}
		}
		// --- <<IS-END>> ---

                
	}



	public static final void get (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(get)>> ---
		// @specification reactiveWM.v1.spec.pub:get
		// @sigtype java 3.5
		IDataCursor pipelineCur = pipeline.getCursor();
		
		try {
			IData[] services = IDataUtil.getIDataArray(pipelineCur, "services");
			
			if(services == null || services.length == 0) {
				return;
			}
			
			String pool = IDataUtil.getString(pipelineCur, "pool");
			boolean failfast = getBoolean(pipelineCur, "failfast", false);
			
			IData timeout = IDataUtil.getIData(pipelineCur, "timeout");			
			if(timeout == null) {
				throw new ServiceException("Timeout not set");
			}
			IDataCursor timeoutCur = timeout.getCursor();
			Long duration = parseDurationTimeout(timeoutCur);
			TimeUnit timeUnit = parseTimeUnitTimeout(timeoutCur);
			timeoutCur.destroy();
			
			IDataCursor servicesCur = null;			
			List<Future<IData>> futures = new ArrayList<Future<IData>>();
			
			for(int i=0; i<services.length; i++) {
				servicesCur = services[i].getCursor();
				
				@SuppressWarnings("unchecked")
				Future<IData> future = (Future<IData>)IDataUtil.get(servicesCur, "future");
				futures.add(future);
			}
			
			ReactiveWMFacade.wait(pool, futures, failfast, duration, timeUnit);
			
			boolean containsErrors = false;
			StringBuilder sb = new StringBuilder();
			
			if(futures != null || futures.size() == 0) {
				int i = 0;
				for(Future<IData> future : futures) {
					servicesCur = services[i++].getCursor();
					IDataUtil.remove(servicesCur, "future");
					try {
						IDataUtil.put(servicesCur, "output", future.get());
						IDataUtil.put(servicesCur, "isOnError", "false");
					} catch(ExecutionException ee) {
						if(containsErrors) {
							sb.append("; ");
						}
						sb.append(ee.getCause().getMessage());
						
						containsErrors = true;
						
						IDataUtil.put(servicesCur, "isOnError", "true");						
						
						IData error = IDataFactory.create();
						IDataCursor errorCur = error.getCursor();						
						IDataUtil.put(errorCur, "errorMessage", ee.getCause().getMessage());
						IDataUtil.put(errorCur, "exception", ee.getCause());						
						errorCur.destroy();
						
						IDataUtil.put(servicesCur, "error", error);
					}
				}
			}
								
			IDataUtil.put(pipelineCur, "containsErrors", Boolean.valueOf(containsErrors).toString());
			if(containsErrors) {
				IDataUtil.put(pipelineCur, "errorMessages", sb.toString());
			}
			
			if(servicesCur != null) {
				servicesCur.destroy();
			}
		} catch(TimeoutException e) {
			throw new ServiceException("Timeout exception");
		}
		catch(Exception e) {
			throw new ServiceException(e);
		} finally {
			if(pipelineCur != null) {
				pipelineCur.destroy();
			}
		}
		// --- <<IS-END>> ---

                
	}



	public static final void parallelize (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(parallelize)>> ---
		// @specification reactiveWM.v1.spec.pub:parallelize
		// @sigtype java 3.5
		IDataCursor pipelineCur = pipeline.getCursor();
		
		try {
			IData[] services = IDataUtil.getIDataArray(pipelineCur, "services");
			
			if(services == null || services.length == 0) {
				return;
			}
			
			String pool = IDataUtil.getString(pipelineCur, "pool");
			
			boolean deepClone = getBoolean(pipelineCur, "deepClone", true);
			boolean failfast = getBoolean(pipelineCur, "failfast", false);
			
			IData timeout = IDataUtil.getIData(pipelineCur, "timeout");			
			if(timeout == null) {
				throw new IllegalArgumentException("Timeout not set");
			}
			IDataCursor timeoutCur = timeout.getCursor();
			Long duration = parseDurationTimeout(timeoutCur);
			TimeUnit timeUnit = parseTimeUnitTimeout(timeoutCur);
			timeoutCur.destroy();
			
			IDataCursor servicesCur = null;
			
			List<ServiceThread> threads = new ArrayList<ServiceThread>();
			
			for(int i=0; i<services.length; i++) {
				servicesCur = services[i].getCursor();
				
				String serviceName = IDataUtil.getString(servicesCur, "serviceName");
				IData input = IDataUtil.getIData(servicesCur, "input");
				String sPriority = IDataUtil.getString(servicesCur, "priority");
				String priorityRef = IDataUtil.getString(servicesCur, "priorityRef");
				boolean interruptable = getBoolean(servicesCur, "interruptable", false);
				
				if(deepClone) {
					if(priorityRef != null) {
						threads.add(ReactiveWMFacade.createServiceThread(pool, serviceName, IDataUtil.deepClone(input), priorityRef, interruptable));
					} else {
						threads.add(ReactiveWMFacade.createServiceThread(pool, serviceName, IDataUtil.deepClone(input), getPriority(sPriority), interruptable));
					}
				} else {
					if(priorityRef != null) {
						threads.add(ReactiveWMFacade.createServiceThread(pool, serviceName, input, priorityRef, interruptable));
					} else {
						threads.add(ReactiveWMFacade.createServiceThread(pool, serviceName, input, getPriority(sPriority), interruptable));
					}
				}
			}
			
			List<Future<IData>> futures = ReactiveWMFacade.parallelize(pool, threads, failfast, duration, timeUnit);
		
			if(futures == null) {
				return;
			}
			
			boolean containsErrors = false;			
			StringBuilder sb = new StringBuilder();
			
			if(futures != null || futures.size() == 0) {
				int i = 0;
				for(Future<IData> future : futures) {
					servicesCur = services[i++].getCursor();
					IDataUtil.remove(servicesCur, "future");
					try {
						IDataUtil.put(servicesCur, "output", future.get());
					} catch(ExecutionException ee) {
						if(containsErrors) {
							sb.append("; ");
						}
						sb.append(ee.getCause().getMessage());
						
						containsErrors = true;
						IDataUtil.put(servicesCur, "isOnError", "false");
						
						IData error = IDataFactory.create();
						IDataCursor errorCur = error.getCursor();						
						IDataUtil.put(errorCur, "errorMessage", ee.getCause().getMessage());
						IDataUtil.put(errorCur, "exception", ee.getCause());
						errorCur.destroy();
						
						IDataUtil.put(servicesCur, "error", error);
					}
				}
			}
			
			IDataUtil.put(pipelineCur, "containsErrors", Boolean.valueOf(containsErrors).toString());
			if(containsErrors) {
				IDataUtil.put(pipelineCur, "errorMessages", sb.toString());
			}
			
			if(servicesCur != null) {
				servicesCur.destroy();
			}
		} catch(FailfastException e) {
			throw new ServiceException(e.getCause().getMessage());
		} catch(TimeoutException e) {
			throw new ServiceException(e);
		} catch(Exception e) {
			throw new ServiceException(e);
		} finally {
			if(pipelineCur != null) {
				pipelineCur.destroy();
			}
		}
		// --- <<IS-END>> ---

                
	}



	public static final void spawn (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(spawn)>> ---
		// @specification reactiveWM.v1.spec.pub:spawn
		// @sigtype java 3.5
		IDataCursor pipelineCur = pipeline.getCursor();
		
		try {
			String serviceName = IDataUtil.getString(pipelineCur, "$serviceName");
			String sPriority = IDataUtil.getString(pipelineCur, "$priority");
			String priorityRef = IDataUtil.getString(pipelineCur, "$priorityRef");
			String pool = IDataUtil.getString(pipelineCur, "$pool");
			boolean deepClone = getBoolean(pipelineCur, "$deepClone", true);
			boolean interruptable = getBoolean(pipelineCur, "$interruptable", false);
			
			IDataUtil.remove(pipelineCur, "$serviceName");
			IDataUtil.remove(pipelineCur, "$priority");
			IDataUtil.remove(pipelineCur, "$priorityRef");
			IDataUtil.remove(pipelineCur, "$pool");
			IDataUtil.remove(pipelineCur, "$deepClone");
			IDataUtil.remove(pipelineCur, "$interruptable");
			
			Future<IData> future = null;
			if(deepClone) {
				if(priorityRef != null) {
					future = ReactiveWMFacade.submit(pool, serviceName, priorityRef, IDataUtil.deepClone(pipeline), interruptable);
				} else {
					future = ReactiveWMFacade.submit(pool, serviceName, getPriority(sPriority), IDataUtil.deepClone(pipeline), interruptable);
				}	
			} else {
				if(priorityRef != null) {
					future = ReactiveWMFacade.submit(pool, serviceName, priorityRef, pipeline, interruptable);
				} else {
					future = ReactiveWMFacade.submit(pool, serviceName, getPriority(sPriority), pipeline, interruptable);
				}
			}
			
			IDataUtil.put(pipelineCur, "future", future);
		} catch(Exception e) {
			throw new ServiceException(e);
		} finally {
			if(pipelineCur != null) {
				pipelineCur.destroy();
			}
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void submit (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(submit)>> ---
		// @specification reactiveWM.v1.spec.pub:submit
		// @sigtype java 3.5
		IDataCursor pipelineCur = pipeline.getCursor();
		
		try {
			IData[] services = IDataUtil.getIDataArray(pipelineCur, "services");
			
			if(services == null || services.length == 0) {
				return;
			}
			
			String pool = IDataUtil.getString(pipelineCur, "pool");
			
			boolean deepClone = getBoolean(pipelineCur, "deepClone", true);
						
			IDataCursor servicesCur = null;
			
			List<Future<IData>> futures = new ArrayList<Future<IData>>();
			
			for(int i=0; i<services.length; i++) {
				servicesCur = services[i].getCursor();
				
				String serviceName = IDataUtil.getString(servicesCur, "serviceName");
				IData input = IDataUtil.getIData(servicesCur, "input");
				String sPriority = IDataUtil.getString(servicesCur, "priority");
				String priorityRef = IDataUtil.getString(servicesCur, "priorityRef");
				boolean interruptable = getBoolean(servicesCur, "interruptable", false);
				
				if(deepClone) {
					if(priorityRef != null) {
						futures.add(ReactiveWMFacade.submit(pool, serviceName, priorityRef, IDataUtil.deepClone(input), interruptable));
					} else {
						futures.add(ReactiveWMFacade.submit(pool, serviceName, getPriority(sPriority), IDataUtil.deepClone(input), interruptable));
					}	
				} else {
					if(priorityRef != null) {
						futures.add(ReactiveWMFacade.submit(pool, serviceName, priorityRef, input, interruptable));
					} else {
						futures.add(ReactiveWMFacade.submit(pool, serviceName, getPriority(sPriority), input, interruptable));
					}
				}
				
			}
			
			if(futures == null || futures.size() != 0) {
				IDataUtil.put(pipelineCur, "futures", futures.toArray(new Future[futures.size()]));
			}
			
			if(servicesCur != null) {
				servicesCur.destroy();
			}
		} catch(Exception e) {
			throw new ServiceException(e);
		} finally {
			if(pipelineCur != null) {
				pipelineCur.destroy();
			}
		}
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	private static final Logger LOG = Logger.getLogger("aif.threadmanager");
	private static final String KEEP_ALIVE_PROPERTY = "watt.aif.threadmanager.worker.keepalive";
	
	private static boolean getBoolean(IDataCursor cursor, String key, boolean defaultValue) {
		String s = IDataUtil.getString(cursor, key);
		if(s == null) {
			return defaultValue;
		}
		return Boolean.valueOf(s);
	}
	
	private static int getPriority(String sPriority) {
		
		int priority = Priority.MID_PRIORITY;
		if(sPriority != null && !"".equals(sPriority)) {
			priority = Integer.valueOf(sPriority);
			if(priority < Priority.MIN_PRIORITY) {
				throw new IllegalArgumentException("Thread priority must be higher than " + Priority.MIN_PRIORITY);
			}
			if(priority > Priority.MAX_PRIORITY) {
				throw new IllegalArgumentException("Thread priority must be lower than " + Priority.MAX_PRIORITY);
			}
		}
		return priority;
	}
	
	private static long parseDurationTimeout(IDataCursor cursor) {
		String s = IDataUtil.getString(cursor, "duration");
		if(s == null || "".equals(s)) {
			throw new IllegalArgumentException("Timeout not set");	
		}			
		return Long.valueOf(s);
	}
	
	private static TimeUnit parseTimeUnitTimeout(IDataCursor cursor) {
		String s = IDataUtil.getString(cursor, "timeUnit");
		if(s == null || "".equals(s)) {
			throw new IllegalArgumentException("Timeout not set");	
		}
		return TimeUnit.valueOf(s);
	}
	
	private static final int MAX_THREADS = ThreadManager.getPoolMax();
		
	// --- <<IS-END-SHARED>> ---
}

